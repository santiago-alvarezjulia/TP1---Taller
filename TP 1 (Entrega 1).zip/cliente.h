#ifndef CLIENTE_H
#define CLIENTE_H

int cliente(const char* hostname, const char* service_name, 
unsigned char* clave, char* nombre_archivo);

#endif //CLIENTE_H
