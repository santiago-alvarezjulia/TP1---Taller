#ifndef SERVIDOR_H
#define SERVIDOR_H

int servidor(const char* service_name, unsigned char* key);

#endif //SERVIDOR_H
