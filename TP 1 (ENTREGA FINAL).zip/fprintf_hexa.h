#ifndef FPRINTF_HEXA_H
#define FPRINTF_HEXA_H

void fprintf_hexa(FILE* file, char* flag, unsigned char* input, int len_input);

#endif // FPRINTF_HEXA_H
