#ifndef CLIENTE_H
#define CLIENTE_H

int cliente(const char* hostname, const char* port, unsigned char* key, 
char* filename);

#endif //CLIENTE_H
