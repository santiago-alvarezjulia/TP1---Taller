#ifndef SOCKET_H
#define SOCKET_H

#include <stddef.h>
#include <stdbool.h>
#include <netdb.h> 

// definicion estructura socket 
typedef struct socket_servidor {
	int socket;
	struct sockaddr* ai_addr;
	socklen_t ai_addrlen;
}socket_servidor_t;

typedef struct socket_cliente {
	int socket;
}socket_cliente_t;


// declaracion primitivas socket
int socket_cliente_create(socket_cliente_t* socket);
int socket_cliente_bind_and_connect(socket_cliente_t* socket, 
const char* hostname, const char* service_name);

int socket_servidor_init(socket_servidor_t* socket_, const char* service_name);
int socket_servidor_init_2(socket_servidor_t* socket_, int socket);
int socket_cliente_send(socket_cliente_t* socket_, 
unsigned char* chunk, size_t sizeof_chunk);

int socket_servidor_receive(socket_servidor_t* socket_, 
unsigned char* chunk, size_t sizeof_chunk);

int socket_servidor_bind_and_listen(socket_servidor_t* socket);
int socket_servidor_accept(socket_servidor_t* socket);
void socket_cliente_shutdown_rw(socket_cliente_t* socket);
void socket_cliente_destroy(socket_cliente_t* socket_);
void socket_servidor_shutdown_rw(socket_servidor_t* socket);
void socket_servidor_destroy(socket_servidor_t* socket_);


#endif // SOCKET_H
