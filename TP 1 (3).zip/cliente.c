#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "arc4.h"
#include "socket.h"
#include "fprintf_personalizados.h"
#define TODO_OK 0
#define ERROR 1
#define ERROR_ENTRADA "Parametros Incorrectos"
#define SIZEOF_CHUNK 64
#define TAMANIO_BYTE 1


int cliente(const char* hostname, const char* service_name, 
unsigned char* clave, char* nombre_archivo) {
	// abro el archivo
	int s;
	FILE* archivo;
	if (nombre_archivo != NULL) {
		archivo = fopen(nombre_archivo, "r");
	} else {
		archivo = stdin;
	}
	if (!archivo) {
		fprintf(stderr, ERROR_ENTRADA);
		return ERROR;
	}
	
	// inicio el socket del cliente
	socket_cliente_t socket;
	s = socket_cliente_create(&socket);
	if (s < 0) {
		fclose(archivo);
		return ERROR;
	}
	s = socket_cliente_bind_and_connect(&socket, hostname, service_name);
	if (s < 0) {
		fclose(archivo);
		socket_cliente_destroy(&socket);
		return ERROR;
	}

	unsigned char chunk[SIZEOF_CHUNK];
	while (true) {
		size_t bytes_leidos = fread(chunk, TAMANIO_BYTE, SIZEOF_CHUNK, archivo); 
		int largo_util_chunk;
		if (bytes_leidos < SIZEOF_CHUNK) {
			largo_util_chunk = bytes_leidos;
		} else {
			largo_util_chunk = SIZEOF_CHUNK;
		} 
		
		arc4_t arc4_;
		arc4_create(&arc4_, largo_util_chunk);
		
		arc4_process(clave, strlen((const char*)clave), chunk, &arc4_);
		fprintf_hexadecimal_stdout((const char*) arc4_get_output(&arc4_));
		fprintf_hexadecimal_stderr((const char*) arc4_get_key_stream(&arc4_));
		socket_cliente_send(&socket, chunk, largo_util_chunk);
		
		arc4_destroy(&arc4_);
		
		if (largo_util_chunk < SIZEOF_CHUNK) {
			break;
		}
	}
	
	socket_cliente_shutdown_rw(&socket);
	socket_cliente_destroy(&socket);
	if (archivo != stdin) {
		fclose(archivo);
	}
	return TODO_OK;
}
