#include "arc4.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#define BYTES 256


void swap(char* array, int i, int j) {
	char k = array[i];
	array[i] = array[j];
	array[j] = k;
}


char gen_pseudoaleatoria(char* state_array, arc4_t* arc4_) {
	arc4_->i = (arc4_->i + 1) &(BYTES - 1);
	arc4_->j = (arc4_->j + state_array[arc4_->i]) &(BYTES - 1);
	swap(state_array, arc4_->i, arc4_->j);
	return state_array[(state_array[arc4_->i] + 
	state_array[arc4_->j]) &(BYTES - 1)];
}

void arc4_create(arc4_t* arc4_, size_t largo_output_and_keystream) {
	arc4_->output = malloc(sizeof(char) * largo_output_and_keystream);
	arc4_->key_stream = malloc(sizeof(char) * largo_output_and_keystream);
	arc4_->i = 0;
	arc4_->j = 0;
}

void arc4_destroy(arc4_t* arc4_) {
	free(arc4_->output);
	free(arc4_->key_stream);
}
	
void arc4_process(unsigned char* clave, 
int largo_clave, unsigned char* input, arc4_t* arc4_) {
	/* Key-Scheduling (KSA) */
	char array_estado[BYTES];

	for(int i = 0; i < BYTES; i++) {
		array_estado[i] = i;
	}
	for(int i = 0, j = 0; i < BYTES; i++) {
		j = (j + clave[i % largo_clave] + array_estado[i]) &(BYTES - 1);
		swap(array_estado, i, j);
	}
	
	/* lleno output y key_stream*/
	for (int k = 0; k < strlen((const char*)input); k++) {
		char char_pseudoaleatorio = gen_pseudoaleatoria(array_estado, arc4_);
		arc4_->output[k] = input[k] ^ char_pseudoaleatorio;
		arc4_->key_stream[k] = char_pseudoaleatorio;
	}
}

unsigned char* arc4_get_output(arc4_t* arc4_) {
	return arc4_->output;
}

unsigned char* arc4_get_key_stream(arc4_t* arc4_) {
	return arc4_->key_stream;
}
 
/*
int main () {
	char* clave = "Key";
	char* input = "Plaintext";
	size_t largo_output_and_keystream = strlen((const char*)input);
	arc4_t arc4_;
	arc4_create(&arc4_, largo_output_and_keystream);
	arc4_process((unsigned char*)clave, strlen((const char*)clave), (unsigned char*)input, &arc4_);
	unsigned char* key_stream = arc4_get_key_stream(&arc4_);
	for (int i = 0; i < strlen((const char*)input); i++){		
		printf("%02X", key_stream[i]);
	}
	printf("\n");
	arc4_destroy(&arc4_);
	return 0;
}
*/
