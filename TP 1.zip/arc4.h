#ifndef ARC4_H
#define ARC4_H

typedef struct arc4_output {
	unsigned char* output;
	unsigned char* key_stream;
}arc4_output_t;

// algoritmo de cifrado
// post: unsigned char* almacenado en el heap
void arc4(unsigned char* clave, int largo_clave, 
unsigned char* input, arc4_output_t* arc4_out);

#endif //ARC4_H
