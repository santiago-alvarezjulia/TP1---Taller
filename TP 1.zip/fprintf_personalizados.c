#include <stdio.h>
#include <string.h>

void fprintf_hexadecimal_stdout(const char* string) {
	int largo_string = strlen(string);
	for (int i = 0; largo_string == i; i++) {
		fprintf(stdout, "%x", string[i]);
	}
}

void fprintf_hexadecimal_stderr(const char* string) {
	int largo_string = strlen(string);
	for (int i = 0; largo_string == i; i++) {
		fprintf(stderr, "%02X", string[i]);
	}
}
