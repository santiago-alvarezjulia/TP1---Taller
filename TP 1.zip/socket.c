#define _POSIX_C_SOURCE 200112L
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <strings.h>
#include <unistd.h>
#include "socket.h"
#define TODO_OK 0
#define ERROR 1
#define CLIENTES_ESPERANDO_MAX 5


// primitivas socket cliente
int socket_cliente_init(socket_cliente_t* socket_, 
const char* hostname, const char* port) {
	struct sockaddr_in sockaddr;
	
	socket_->socket = socket(AF_INET, SOCK_STREAM, 0);
	sockaddr.sin_family = AF_INET;
	sockaddr.sin_port = htons((uint16_t)atoi(port));
	sockaddr.sin_addr.s_addr = (unsigned long) hostname;
	bzero(&(sockaddr.sin_zero), 8);
	socket_->sockaddr = sockaddr;
	return TODO_OK;
}


int socket_cliente_bind_and_connect(socket_cliente_t* socket_){
	int s = connect(socket_->socket, 
	(struct sockaddr*) &(socket_->sockaddr), sizeof(struct sockaddr));
	if (s < 0) {
		fprintf(stderr, "Error en getaddrinfo: %s\n", gai_strerror(s));
		return ERROR;
	}
	return TODO_OK;
}


int socket_cliente_send(socket_cliente_t* socket_, 
unsigned char* chunk, size_t sizeof_chunk) {
	int bytes_enviados = 0;
	int s;
	bool es_socket_valido = true;
	
	while(bytes_enviados < sizeof_chunk) {
		s = send(socket_->socket, &chunk[bytes_enviados], 
		sizeof_chunk - bytes_enviados, MSG_NOSIGNAL);
		if (s < 0) {
			socket_cliente_destroy(socket_);
			return ERROR;
		} else if (s == 0) {
			es_socket_valido = false;
		} else {
			bytes_enviados += s;
		}
	}	
		
	if (es_socket_valido) {
		return TODO_OK;
	}
	return ERROR;
}


int socket_servidor_init(socket_servidor_t* socket_, const char* service_name) {
	struct addrinfo hints;
	struct addrinfo *result;
	int s = 0;
	
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	s = getaddrinfo(NULL, service_name, &hints, &result);
	
	socket_->ai_addr = result->ai_addr;
	socket_->ai_addrlen = result->ai_addrlen;
	
	if (s != 0) {
		fprintf(stderr, "Error en getaddrinfo: %s\n", gai_strerror(s));
		return ERROR;
	}
	
	socket_->socket = socket(result->ai_family, 
	result->ai_socktype, result->ai_protocol);
	if (socket_->socket == -1) {
		fprintf(stderr, "Error : %s\n", strerror(errno));
		freeaddrinfo(result);
		return ERROR;
	}	
	
	freeaddrinfo(result);
	return TODO_OK; 
}


int socket_servidor_init_2(socket_servidor_t* socket_, int socket_asociado) {
	socket_->socket = socket_asociado;
	return TODO_OK;
}
	
int socket_servidor_bind_and_listen(socket_servidor_t* socket_) {
	int s = bind(socket_->socket, socket_->ai_addr, socket_->ai_addrlen);
	if (s == -1) {
		fprintf(stderr,"Error : %s\n", strerror(errno));
		socket_servidor_destroy(socket_);
		return ERROR;
	}
	
	s = listen(socket_->socket, CLIENTES_ESPERANDO_MAX);
	if (s == -1) {
		fprintf(stderr,"Error : %s\n", strerror(errno));
		socket_servidor_destroy(socket_);
		return ERROR;
	}
	return TODO_OK;
}

int socket_servidor_accept(socket_servidor_t* socket_){
	int s = accept(socket_->socket, NULL, NULL);
	if (s < 0) {
		socket_servidor_destroy(socket_);
		return ERROR;
	}
	return TODO_OK;
}


int socket_servidor_receive(socket_servidor_t* socket_, 
unsigned char* chunk, size_t sizeof_chunk) {
	int bytes_recibidos = 0;
	int s;
	bool es_socket_valido = true;
	
	while(bytes_recibidos < sizeof_chunk) {
		s = recv(socket_->socket, &chunk[bytes_recibidos], 
		sizeof_chunk - bytes_recibidos, MSG_NOSIGNAL);
		if (s < 0) {
			socket_servidor_destroy(socket_);
			return ERROR;
		} else if (s == 0) {
			es_socket_valido = false;
		} else {	
			bytes_recibidos += s;
		}
	}	
		
	if (es_socket_valido) {
		return bytes_recibidos;
	}
	return ERROR;
}


void socket_cliente_shutdown_rw(socket_cliente_t* socket_) {
	shutdown(socket_->socket, SHUT_RDWR);
}


void socket_servidor_shutdown_rw(socket_servidor_t* socket_) {
	shutdown(socket_->socket, SHUT_RDWR);
}

void socket_cliente_destroy(socket_cliente_t* socket_) {
	close(socket_->socket);
}


void socket_servidor_destroy(socket_servidor_t* socket_) {
	close(socket_->socket);
}
