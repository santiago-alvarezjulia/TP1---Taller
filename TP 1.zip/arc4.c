#include "arc4.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define BYTES 256

int i, j;


void swap(char* array, int i, int j) {
	char k = array[i];
	array[i] = array[j];
	array[j] = k;
}


char gen_pseudoaleatoria(char* state_array) {
	i = (i + 1) &(BYTES - 1);
	j = (j + state_array[i]) &(BYTES - 1);
	swap(state_array, i, j);
	return state_array[(state_array[i] + state_array[j]) &(BYTES - 1)];
}


void arc4(unsigned char* clave, 
int largo_clave, unsigned char* input, arc4_output_t* arc4_out) {
	/* Key-Scheduling (KSA) */
	char array_estado[BYTES];

	for(int i = 0; i < BYTES; i++) {
		array_estado[i] = i;
	}
	for(int i = 0, j = 0; i < BYTES; i++) {
		j = (j + clave[i % largo_clave] + array_estado[i]) &(BYTES - 1);
		swap(array_estado, i, j);
	}
	/* lleno output y key_stream*/
	for (int k = 0; k < strlen((const char*)input); k++) {
		char char_pseudoaleatorio = gen_pseudoaleatoria(array_estado);
		arc4_out->output[k] = input[k] ^ char_pseudoaleatorio;
		arc4_out->key_stream[k] = char_pseudoaleatorio;
	}
}

/*
int main () {
	char* clave = "Key";
	char* input = "Plaintext";
	arc4_output_t arc4_out;
	(&arc4_out)->output = malloc(sizeof(char) * strlen((const char*)input));
	(&arc4_out)->key_stream = malloc(sizeof(char) * strlen((const char*)input));
	arc4((unsigned char*)clave, strlen((const char*)clave), (unsigned char*)input, &arc4_out);
	for (int i = 0; i < strlen((const char*)input); i++){
		printf("%02X", (&arc4_out)->key_stream[i]);
	}
	printf("\n");
	return 0;
}
*/
