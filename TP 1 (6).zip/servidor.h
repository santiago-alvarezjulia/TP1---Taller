#ifndef SERVIDOR_H
#define SERVIDOR_H

int servidor(const char* service_name, unsigned char* clave);

#endif //SERVIDOR_H
