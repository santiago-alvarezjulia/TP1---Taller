#ifndef FPRINTF_PERSONALIZADOS_H
#define FPRINTF_PERSONALIZADOS_H

void fprintf_hexadecimal_stdout(const char* string);

void fprintf_hexadecimal_stderr(const char* string);

#endif
